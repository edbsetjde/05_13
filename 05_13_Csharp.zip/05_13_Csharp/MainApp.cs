﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace _05_13_Csharp
{
    internal class MainApp
    {
        static double GetDiscountRate(object client)
        {
            return client switch //switch 식이라고 부른다. case문을 사용하지 않고 패턴 매칭을 통해 switch문을 사용할수 있다.
            {
                ("학생", int n) when n < 18 => 0.2, //학생 & 18세 미만
                ("학생", _) => 0.1, //학생 & 18세 이상
                ("일반", int n) when n < 18 => 0.1, //일반 & 18세 미만
                ("일반", _) => 0.05, //일반 & 18세 이상
                _ => 0,
            };

        }
        static double GetDiscountRate2(object client)
        {

            if (client is ValueTuple<string, int> tuple)
            {
                string clientType = tuple.Item1;
                int age = tuple.Item2;

                switch (clientType)
                {
                    case "학생"when age < 18:
                        return 0.2;
                    case "학생":
                        return 0.1;
                    case "일반" when age < 18:
                        return 0.1;
                    case "일반":
                        return 0.05;
                    default:
                        return 0;
                }
            }
            return 0;
        }
            static double GetDiscountRate3(object client)
        {
            if (client is ValueTuple<string, int> studentUnder18 && studentUnder18.Item1 == "학생" && studentUnder18.Item2 < 18)
            {
                return 0.2;
            }
            else if (client is ValueTuple<string, int> studentOverOrEqual18 && studentOverOrEqual18.Item1 == "학생")
            {
                return 0.1;
            }
            else if (client is ValueTuple<string, int> generalUnder18 && generalUnder18.Item1 == "일반" && generalUnder18.Item2 < 18)
            {
                return 0.1;
            }
            else if (client is ValueTuple<string, int> generalOverOrEqual18 && generalOverOrEqual18.Item1 == "일반")
            {
                return 0.05;
            }
            else
            {
                return 0;
            }
        }

        static void Main(string[] args)
        {
            var allic = (job: "학생", Age: 17);
            var bob = (job: "학생", Age: 23);
            var charlie = (job: "일반", Age: 15);
            var dave = (job: "일반", Age: 25);
            var a = (job: "", Age: 20);
            Console.WriteLine(GetDiscountRate(allic));
            Console.WriteLine(GetDiscountRate(bob));
            Console.WriteLine(GetDiscountRate(charlie));
            Console.WriteLine(GetDiscountRate(dave));
            Console.WriteLine(GetDiscountRate(a));
            Console.WriteLine(GetDiscountRate2(allic));
            Console.WriteLine(GetDiscountRate2(bob));
            Console.WriteLine(GetDiscountRate2(charlie));
            Console.WriteLine(GetDiscountRate2(dave));
            Console.WriteLine(GetDiscountRate2(a));
        }
    }
}
