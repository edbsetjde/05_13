﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace _05_13_Csharp
//{
//    internal class Problum
//    {
//        struct ACSetting
//        {
//            public double currentInCelsius; //현재온도 도씨
//            public double target; // 희망온도 

//            public readonly double GetFahrenheit()
//            { 
//                return currentInCelsius * 1.8 + 32f;
//            }
//        }

//        static void Main(string[] args)
//        {
//            ACSetting acs;
//            acs.currentInCelsius = 25;
//            acs.target = 25;

//            Console.WriteLine($"{acs.GetFahrenheit()}");
//            Console.WriteLine($"{acs.target}");
//        }
//    }
//}
