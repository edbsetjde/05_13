﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace _05_13_Csharp
//{
//    internal class Program
//    {

//        static void Main(string[] args)
//        {

//            #region 튜플 연습
//            //var tuple = (123, 456 );
//            //Console.WriteLine($"{tuple.Item1},{tuple.Item2}");
//            //var tuple2 = (Name : "서예지", Age : 38);
//            //Console.WriteLine($"{ tuple2.Name},{tuple2.Age}");
//            //var tuple3 = (Name: "유아인", Age: 38, Address : "서울시");
//            //Console.WriteLine($"{tuple3.Name},{tuple3.Age},{tuple3.Address}");
//            //var num = (Name: "김문수", Age: 75);
//            //var (Name, _) = num; //분해 Age는 무시
//            //Console.WriteLine($"이름: {Name}");

//            //var (name2, age2) = ("서예지", 35);
//            //Console.WriteLine($"이름: {name2}, 나이: {age2}");

//            //var unnamed = ("수퍼맨", 9999);
//            //var named = (Name: "배트맨", Age: 46);
//            //Console.WriteLine($"{named.Name}, {named.Age}");
//            //named = unnamed; //named 는 unnamed로 초기화
//            //Console.WriteLine($"{named.Name}, {named.Age}");
//            #endregion

//            var a = ("수퍼맨", 9999); // 명명되지 않은 튜플
//            Console.WriteLine($"{a.Item1} {a.Item2}");
//            var b = (Name: "배트맨", Age: 46); //명명된 튜플
//            Console.WriteLine($"{b.Name}, {b.Age}");

//            var (name, age) = b;
//            Console.WriteLine($"이름: {name}, 나이: {age}");
//            var (name2, age2) = ("", 35);
//            Console.WriteLine($"이름: {name2}, 나이: {age2}");
//            b = a;
//            Console.WriteLine($"{b.Name}, {b.Age}");

//        }
//    }
//}
